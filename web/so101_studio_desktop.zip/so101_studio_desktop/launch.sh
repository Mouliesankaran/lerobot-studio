#!/usr/bin/env bash
exec "$(dirname "$0")/run_ubuntu.sh" "$@"
