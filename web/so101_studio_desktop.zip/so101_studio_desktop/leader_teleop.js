/**
 * SO-101 Leader-Follower Bilateral Teleoperation Frontend Controller
 * Communicates with /api/teleop/leader_sync/* endpoints
 */

(function () {
  let leaderPollTimer = null;
  let isSyncing = false;

  const JOINT_LABELS = {
    shoulder_pan: "Joint 1 (Shoulder Pan)",
    shoulder_lift: "Joint 2 (Shoulder Lift)",
    elbow_flex: "Joint 3 (Elbow Flex)",
    wrist_flex: "Joint 4 (Wrist Flex)",
    wrist_roll: "Joint 5 (Wrist Roll)",
    gripper: "Joint 6 (Gripper)"
  };

  function initLeaderTeleop() {
    const modeSelect = document.getElementById("teleop-mode-select");
    const panel = document.getElementById("teleop-leader-panel");
    const btnStart = document.getElementById("btn-leader-start");
    const btnStop = document.getElementById("btn-leader-stop");
    const btnRefreshPorts = document.getElementById("btn-leader-refresh-ports");
    const portSelect = document.getElementById("leader-port-select");

    if (!modeSelect || !panel) return;

    // Toggle visibility when mode selector changes
    modeSelect.addEventListener("change", () => {
      if (modeSelect.value === "leader") {
        panel.classList.add("active");
        fetchStatus();
        startPolling();
      } else {
        panel.classList.remove("active");
        stopPolling();
      }
    });

    if (btnStart) {
      btnStart.addEventListener("click", () => {
        const port = portSelect ? portSelect.value : "/dev/ttyACM1";
        startSync(port);
      });
    }

    if (btnStop) {
      btnStop.addEventListener("click", () => {
        stopSync();
      });
    }

    if (btnRefreshPorts) {
      btnRefreshPorts.addEventListener("click", () => {
        fetchStatus();
      });
    }

    // Initial check if mode is already leader
    if (modeSelect.value === "leader") {
      panel.classList.add("active");
      fetchStatus();
      startPolling();
    }
  }

  function startPolling() {
    if (leaderPollTimer) clearInterval(leaderPollTimer);
    leaderPollTimer = setInterval(fetchStatus, 150);
  }

  function stopPolling() {
    if (leaderPollTimer) {
      clearInterval(leaderPollTimer);
      leaderPollTimer = null;
    }
  }

  async function fetchStatus() {
    try {
      const res = await fetch("/api/teleop/leader_sync/status");
      if (!res.ok) return;
      const data = await res.json();
      updateUI(data);
    } catch (err) {
      // ignore offline bridge
    }
  }

  function updateUI(data) {
    isSyncing = !!data.syncing;

    // Update Badges & Buttons
    const badge = document.getElementById("leader-sync-badge");
    const btnStart = document.getElementById("btn-leader-start");
    const btnStop = document.getElementById("btn-leader-stop");
    const hzEl = document.getElementById("leader-hz-val");
    const latEl = document.getElementById("leader-lat-val");
    const framesEl = document.getElementById("leader-frames-val");
    const portSelect = document.getElementById("leader-port-select");
    const followerPortEl = document.getElementById("leader-follower-port-display");

    if (badge) {
      if (isSyncing) {
        badge.innerText = data.is_simulation ? "SYNCING (SIMULATED)" : "SYNCING (50 HZ)";
        badge.className = "leader-badge syncing";
      } else {
        badge.innerText = "STANDBY";
        badge.className = "leader-badge";
      }
    }

    if (btnStart && btnStop) {
      btnStart.style.display = isSyncing ? "none" : "inline-flex";
      btnStop.style.display = isSyncing ? "inline-flex" : "none";
    }

    if (hzEl) hzEl.innerText = `${data.loop_hz || 0.0} Hz`;
    if (latEl) latEl.innerText = `${data.latency_ms || 0.0} ms`;
    if (framesEl) framesEl.innerText = (data.frame_count || 0).toLocaleString();
    if (followerPortEl) followerPortEl.innerText = data.follower_port || "Auto-Bridge";

    // Populate candidate ports if dropdown is empty
    if (portSelect && data.available_ports && portSelect.options.length <= 1) {
      const currentVal = portSelect.value;
      portSelect.innerHTML = "";
      data.available_ports.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p;
        opt.innerText = p.includes("ACM") || p.includes("USB") ? `🔌 Leader Arm: ${p}` : `⚙️ ${p}`;
        portSelect.appendChild(opt);
      });
      if (currentVal && Array.from(portSelect.options).some(o => o.value === currentVal)) {
        portSelect.value = currentVal;
      }
    }

    // Render 6-DOF Joint Alignment Gauges
    const leaderAngles = data.leader_angles || {};
    const followerAngles = data.follower_angles || {};
    const errors = data.errors || {};

    Object.keys(JOINT_LABELS).forEach(jkey => {
      const lVal = leaderAngles[jkey] !== undefined ? leaderAngles[jkey].toFixed(1) : "0.0";
      const fVal = followerAngles[jkey] !== undefined ? followerAngles[jkey].toFixed(1) : "0.0";
      const errVal = errors[jkey] !== undefined ? errors[jkey].toFixed(1) : "0.0";

      const lEl = document.getElementById(`lf-lead-${jkey}`);
      const fEl = document.getElementById(`lf-foll-${jkey}`);
      const errEl = document.getElementById(`lf-err-${jkey}`);
      const barEl = document.getElementById(`lf-bar-${jkey}`);

      if (lEl) lEl.innerText = `${lVal}°`;
      if (fEl) fEl.innerText = `${fVal}°`;
      if (errEl) {
        errEl.innerText = `Δ ${errVal}°`;
        const errNum = parseFloat(errVal);
        errEl.style.color = errNum <= 1.5 ? "#22c55e" : (errNum <= 3.5 ? "#f59e0b" : "#ef4444");
      }
      if (barEl) {
        // Map degrees to bar percentage (0-100%)
        const norm = jkey === "gripper" ? parseFloat(lVal) : Math.min(100, Math.max(0, (parseFloat(lVal) + 90) / 1.8));
        barEl.style.width = `${norm}%`;
      }
    });
  }

  async function startSync(port) {
    try {
      const res = await fetch("/api/teleop/leader_sync/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leader_port: port, baud: 1000000 })
      });
      const data = await res.json();
      if (!data.success) {
        alert(data.message || "Failed to start leader-follower teleoperation.");
      } else {
        fetchStatus();
      }
    } catch (err) {
      alert("Error contacting hardware bridge: " + err);
    }
  }

  async function stopSync() {
    try {
      const res = await fetch("/api/teleop/leader_sync/stop", {
        method: "POST"
      });
      const data = await res.json();
      fetchStatus();
    } catch (err) {
      console.warn("Stop sync err:", err);
    }
  }

  // Hook into DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initLeaderTeleop);
  } else {
    initLeaderTeleop();
  }
})();
