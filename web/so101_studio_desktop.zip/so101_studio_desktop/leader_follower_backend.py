#!/usr/bin/env python3
"""
SO-101 Leader-Follower Bilateral Teleoperation Backend
Coordinates dual-port serial bus communication:
- Leader Arm: Manual compliant arm (Torque OFF, reading 50Hz encoder feedback)
- Follower Arm: Physical slave arm (Torque ON, mirroring leader joint angles with safety clamping)
"""

import time
import math
import json
import threading
import serial
from typing import Dict, Any, Optional
import tornado.web

# Default servo limits
DEFAULT_CALIBRATION = {
    1: {"name": "shoulder_pan",  "min": 1197, "max": 3113, "deg_min": -84.1, "deg_max": 84.1},
    2: {"name": "shoulder_lift", "min": 1,    "max": 4091, "deg_min": -179.9, "deg_max": 179.9},
    3: {"name": "elbow_flex",    "min": 0,    "max": 4094, "deg_min": -180.0, "deg_max": 179.9},
    4: {"name": "wrist_flex",    "min": 1102, "max": 3022, "deg_min": -84.3, "deg_max": 84.3},
    5: {"name": "wrist_roll",    "min": 0,    "max": 4095, "deg_min": -180.0, "deg_max": 180.0},
    6: {"name": "gripper",       "min": 2013, "max": 3505, "deg_min": 0.0,   "deg_max": 100.0},
}


def calc_sts_checksum(pkt: bytearray) -> int:
    return (~sum(pkt[2:])) & 0xFF


class LeaderArmDriver:
    """Reads compliant manual positions from the Leader arm."""

    def __init__(self):
        self.port = ""
        self.baudrate = 1000000
        self.timeout = 0.03
        self.is_connected = False
        self.is_simulation = False
        self._ser: Optional[serial.Serial] = None
        self.lock = threading.RLock()
        self.calibration = DEFAULT_CALIBRATION

    def connect(self, port: str, baudrate: int = 1000000) -> bool:
        with self.lock:
            self.disconnect()
            self.port = port
            self.baudrate = baudrate
            if port == "SIMULATION" or port == "sim":
                self.is_connected = True
                self.is_simulation = True
                print("[LEADER] Connected to Simulated Leader Arm.")
                return True

            try:
                self._ser = serial.Serial(self.port, self.baudrate, timeout=self.timeout)
                self._ser.reset_input_buffer()
                self._ser.reset_output_buffer()
                self.is_connected = True
                self.is_simulation = False
                print(f"[LEADER] Connected to Leader arm on {self.port} at {self.baudrate} baud.")
                # Immediately ensure torque is OFF so leader arm is freely movable by hand
                self.set_torque(False)
                return True
            except Exception as e:
                print(f"[LEADER-WARN] Could not connect to {self.port}: {e}")
                self.is_connected = False
                self.is_simulation = False
                return False

    def disconnect(self):
        with self.lock:
            if self._ser is not None and self._ser.is_open:
                try:
                    self.set_torque(False)
                    self._ser.close()
                except Exception:
                    pass
                self._ser = None
            self.is_connected = False
            self.is_simulation = False

    def set_torque(self, enable: bool):
        if not self._ser or not self._ser.is_open:
            return
        val = 1 if enable else 0
        pkt = bytearray([0xFF, 0xFF, 0xFE, 16, 0x83, 40, 1])
        for sid in range(1, 7):
            pkt.append(sid)
            pkt.append(val)
        pkt.append(calc_sts_checksum(pkt))
        try:
            self._ser.write(pkt)
        except Exception:
            pass

    def ticks_to_deg(self, sid: int, ticks: int) -> float:
        cal = self.calibration.get(sid, {})
        c_min = cal.get("min", 0)
        c_max = cal.get("max", 4095)
        if sid == 6:
            pct = ((ticks - c_min) / max(1, c_max - c_min)) * 100.0
            return max(0.0, min(100.0, pct))
        mid = (c_min + c_max) / 2.0
        deg = (ticks - mid) * (360.0 / 4095.0)
        return max(cal.get("deg_min", -180.0), min(cal.get("deg_max", 180.0), deg))

    def read_all_joints(self) -> Dict[str, float]:
        """Read 6 joint angles from leader arm in degrees/pct."""
        if self.is_simulation:
            t = time.time()
            return {
                "shoulder_pan": round(25.0 * math.sin(t * 0.9), 2),
                "shoulder_lift": round(15.0 * math.cos(t * 0.7), 2),
                "elbow_flex": round(-10.0 * math.sin(t * 0.5), 2),
                "wrist_flex": round(12.0 * math.cos(t * 1.1), 2),
                "wrist_roll": round(8.0 * math.sin(t * 0.6), 2),
                "gripper": round(50.0 + 35.0 * math.sin(t * 0.8), 2)
            }

        angles = {}
        if not self.is_connected or not self._ser:
            return angles

        with self.lock:
            for sid, cal in self.calibration.items():
                try:
                    pkt = bytearray([0xFF, 0xFF, sid, 4, 0x02, 56, 8])
                    pkt.append(calc_sts_checksum(pkt))
                    self._ser.reset_input_buffer()
                    self._ser.write(pkt)
                    resp = self._ser.read(14)
                    if len(resp) >= 14 and resp[0] == 0xFF and resp[1] == 0xFF and resp[2] == sid:
                        pos_raw = int.from_bytes(resp[5:7], "little", signed=True)
                        angles[cal["name"]] = self.ticks_to_deg(sid, pos_raw)
                except Exception:
                    pass
        return angles


class LeaderFollowerSyncManager:
    """Manages bilateral Leader -> Follower streaming loop."""

    def __init__(self, follower_driver=None):
        self.follower_driver = follower_driver
        self.leader_driver = LeaderArmDriver()
        self.is_syncing = False
        self.sync_thread: Optional[threading.Thread] = None
        self.stop_event = threading.Event()

        # Telemetry metrics
        self.loop_hz = 0.0
        self.latency_ms = 0.0
        self.latest_leader_angles: Dict[str, float] = {}
        self.latest_follower_angles: Dict[str, float] = {}
        self.latest_errors: Dict[str, float] = {}
        self.frame_count = 0

    def start_sync(self, leader_port: str, baudrate: int = 1000000) -> Dict[str, Any]:
        if self.is_syncing:
            return {"success": True, "message": "Already syncing."}

        # 1. Connect leader
        if not self.leader_driver.is_connected or self.leader_driver.port != leader_port:
            ok = self.leader_driver.connect(leader_port, baudrate)
            if not ok:
                return {"success": False, "message": f"Could not open Leader arm on {leader_port}"}

        # 2. Check follower
        if not self.follower_driver or not getattr(self.follower_driver, "is_connected", False):
            # If simulated, allow sync test
            if getattr(self.leader_driver, "is_simulation", False) or leader_port == "SIMULATION":
                print("[SYNC] Operating in simulation test mode (Follower not connected).")
            else:
                return {"success": False, "message": "Follower arm is not connected. Please connect Follower arm first or select SIMULATION."}

        # Ensure follower torque is ON
        if self.follower_driver and getattr(self.follower_driver, "is_connected", False):
            self.follower_driver.set_torque(True)

        self.stop_event.clear()
        self.is_syncing = True
        self.sync_thread = threading.Thread(target=self._sync_loop, daemon=True)
        self.sync_thread.start()
        print(f"[SYNC] Started Leader ({leader_port}) -> Follower ({self.follower_driver.port}) real-time teleoperation.")
        return {"success": True, "message": "Leader-Follower teleoperation active."}

    def stop_sync(self) -> Dict[str, Any]:
        self.is_syncing = False
        self.stop_event.set()
        if self.sync_thread and self.sync_thread.is_alive():
            self.sync_thread.join(timeout=1.0)
        self.leader_driver.disconnect()
        print("[SYNC] Stopped Leader-Follower teleoperation.")
        return {"success": True, "message": "Teleoperation stopped."}

    def _sync_loop(self):
        """50 Hz Leader reading & Follower synchronous driving loop."""
        rate = 50.0  # 50 Hz
        interval = 1.0 / rate
        last_t = time.perf_counter()

        while not self.stop_event.is_set():
            t0 = time.perf_counter()

            # Read Leader
            leader_angles = self.leader_driver.read_all_joints()
            if leader_angles and len(leader_angles) >= 4:
                self.latest_leader_angles = dict(leader_angles)

                # Send to Follower
                if self.follower_driver and getattr(self.follower_driver, "is_connected", False):
                    self.follower_driver.sync_write_all(leader_angles, speed_rad_s=2.5)
                    if hasattr(self.follower_driver, "last_actual_positions") and self.follower_driver.last_actual_positions:
                        self.latest_follower_angles = dict(self.follower_driver.last_actual_positions)
                    else:
                        self.latest_follower_angles = dict(leader_angles)
                else:
                    self.latest_follower_angles = dict(leader_angles)

                # Compute errors
                self.latest_errors = {
                    k: round(abs(leader_angles.get(k, 0.0) - self.latest_follower_angles.get(k, 0.0)), 2)
                    for k in leader_angles
                }

                # Calculate latency & errors
                t1 = time.perf_counter()
                self.latency_ms = (t1 - t0) * 1000.0
                dt = t0 - last_t
                if dt > 0:
                    self.loop_hz = 0.9 * self.loop_hz + 0.1 * (1.0 / dt)
                last_t = t0
                self.frame_count += 1

            # Sleep remaining time
            elapsed = time.perf_counter() - t0
            to_sleep = interval - elapsed
            if to_sleep > 0:
                time.sleep(to_sleep)

    def get_status(self) -> Dict[str, Any]:
        ports = []
        try:
            import serial.tools.list_ports
            ports = [p.device for p in serial.tools.list_ports.comports()]
        except Exception:
            pass
        if "SIMULATION" not in ports:
            ports.append("SIMULATION")

        return {
            "syncing": self.is_syncing,
            "leader_connected": self.leader_driver.is_connected,
            "is_simulation": getattr(self.leader_driver, "is_simulation", False),
            "leader_port": self.leader_driver.port,
            "follower_port": self.follower_driver.port if self.follower_driver and getattr(self.follower_driver, "is_connected", False) else "Not Connected",
            "loop_hz": round(self.loop_hz, 1),
            "latency_ms": round(self.latency_ms, 1),
            "leader_angles": self.latest_leader_angles,
            "follower_angles": self.latest_follower_angles,
            "errors": self.latest_errors,
            "frame_count": self.frame_count,
            "available_ports": ports
        }


# Global Manager Instance
leader_sync_manager: Optional[LeaderFollowerSyncManager] = None


def init_leader_follower_manager(follower_driver):
    global leader_sync_manager
    if leader_sync_manager is None:
        leader_sync_manager = LeaderFollowerSyncManager(follower_driver)
    return leader_sync_manager


# ----------------------------------------------------
# HTTP API HANDLERS
# ----------------------------------------------------
class LeaderSyncStartHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Headers", "Content-Type")
        self.set_header("Access-Control-Allow-Methods", "POST, OPTIONS")

    def options(self):
        self.set_status(204)
        self.finish()

    def post(self):
        self.set_header("Content-Type", "application/json")
        try:
            req = json.loads(self.request.body.decode("utf-8")) if self.request.body else {}
        except Exception:
            req = {}
        port = req.get("leader_port", "/dev/ttyACM1")
        baud = int(req.get("baud", 1000000))
        if leader_sync_manager:
            res = leader_sync_manager.start_sync(port, baud)
            self.write(json.dumps(res))
        else:
            self.write(json.dumps({"success": False, "message": "Leader manager not initialized"}))


class LeaderSyncStopHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Headers", "Content-Type")
        self.set_header("Access-Control-Allow-Methods", "POST, OPTIONS")

    def options(self):
        self.set_status(204)
        self.finish()

    def post(self):
        self.set_header("Content-Type", "application/json")
        if leader_sync_manager:
            res = leader_sync_manager.stop_sync()
            self.write(json.dumps(res))
        else:
            self.write(json.dumps({"success": True}))


class LeaderSyncStatusHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Headers", "Content-Type")
        self.set_header("Access-Control-Allow-Methods", "GET, OPTIONS")

    def options(self):
        self.set_status(204)
        self.finish()

    def get(self):
        self.set_header("Content-Type", "application/json")
        if leader_sync_manager:
            self.write(json.dumps(leader_sync_manager.get_status()))
        else:
            self.write(json.dumps({"syncing": False, "leader_connected": False}))


LEADER_ROUTES = [
    (r"/api/teleop/leader_sync/start", LeaderSyncStartHandler),
    (r"/api/teleop/leader_sync/stop", LeaderSyncStopHandler),
    (r"/api/teleop/leader_sync/status", LeaderSyncStatusHandler),
]
